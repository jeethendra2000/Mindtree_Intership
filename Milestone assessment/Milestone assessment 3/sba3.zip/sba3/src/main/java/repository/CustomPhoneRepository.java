package repository;
import java.util.List;

import mikail.phone_store.model.Phone;

public class CustomPhoneRepository {
    List<Phone> getNamesLikeOrBrandLike(String name);
}
