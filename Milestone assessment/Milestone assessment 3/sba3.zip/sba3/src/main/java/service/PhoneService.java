package service;
import java.util.List;

import mobile.Phone;

public class PhoneService {
    public List<Phone> getAllPhones();
    public List<Phone> getPhones(String brand);
}
