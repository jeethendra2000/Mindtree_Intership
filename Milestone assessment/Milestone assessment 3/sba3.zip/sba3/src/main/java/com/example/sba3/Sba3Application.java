package com.example.sba3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sba3Application {

    public static void main(String[] args) {
        SpringApplication.run(Sba3Application.class, args);
    }

}
