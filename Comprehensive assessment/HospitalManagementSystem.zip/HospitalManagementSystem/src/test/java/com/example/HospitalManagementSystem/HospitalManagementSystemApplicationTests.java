package com.example.HospitalManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
